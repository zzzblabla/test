#include "pch.h"
#include "fitting_solver.h"

COMMON_BEGIN_NAMESPACE

FittingSolver::FittingSolver() {

}

FittingSolver::~FittingSolver() {

}

COMMON_END_NAMESPACE