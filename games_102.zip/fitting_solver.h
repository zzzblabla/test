#ifndef FITTING_SOLVER_H_
#define FITTING_SOLVER_H_

#include <vector>
#include "common_config.h"

COMMON_BEGIN_NAMESPACE

class Point;
class FittingSolver {
public:
	FittingSolver();
	virtual ~FittingSolver() = 0;
	virtual bool Solve(std::vector<Point>& points) = 0;
};

COMMON_END_NAMESPACE

#endif // ! FITTING_SOLVER_H_