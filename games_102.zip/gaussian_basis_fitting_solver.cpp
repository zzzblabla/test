#include "pch.h"
#include <algorithm>
#include <Eigen/Dense>
#include "point.h"
#include "gaussian_basis_fitting_solver.h"

COMMON_BEGIN_NAMESPACE

double GaussianBasisFunction(double dX, double dCenter, double dDelta) {
	double dDistance = dX - dCenter;
	return exp(-dDistance * dDistance / (2 * dDelta));
}

GaussianBasisFittingSolver::GaussianBasisFittingSolver() {

}

GaussianBasisFittingSolver::~GaussianBasisFittingSolver() {

}

bool GaussianBasisFittingSolver::Solve(std::vector<Point>& points) {
	std::sort(points.begin(), points.end(), [](const Point& x, const Point& y)
		{
			return x.GetX() < y.GetX() || (x.GetX() == y.GetX() && x.GetY() < y.GetY());
		});
	size_t point_size = points.size();
	std::vector<double> vCoefficients(point_size, 0);
	Eigen::MatrixXd coefficients(point_size, point_size);
	Eigen::MatrixXd value(point_size, 1);
	for (size_t index = 0; index < point_size; index++) {
		double dX = points[index].GetX();
		for (size_t basis_index = 0; basis_index < point_size; basis_index++) {
			coefficients(index, basis_index) = GaussianBasisFunction(dX, points[basis_index].GetX(), 1.0);
		}
		value(index, 0) = points[index].GetY();
	}
	auto solution = coefficients.inverse() * value;
	last_solution_.clear();
	for (size_t basis_index = 0; basis_index < point_size; basis_index++) {
		last_solution_.emplace_back(solution(basis_index, 0), points[basis_index].GetX());
	}
	return true;
}

const std::vector<std::tuple<double, double>>& GaussianBasisFittingSolver::GetLastSolution() const {
	return last_solution_;
}

COMMON_END_NAMESPACE