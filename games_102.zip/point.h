#ifndef POINT_H_
#define POINT_H_

#include "common_config.h"

COMMON_BEGIN_NAMESPACE

class _DLL_DECLARE_ Point {
public:
	Point();
	Point(double x, double y);
	~Point();
	double GetX() const;
	double GetY() const;

private:
	double _dX;
	double _dY;
};

COMMON_END_NAMESPACE

#endif // ! POINT_H_