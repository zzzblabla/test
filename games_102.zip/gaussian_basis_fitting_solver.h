#pragma once
#ifndef GAUSSIAN_BASIS_FITTING_SOLVER_H_
#define GAUSSIAN_BASIS_FITTING_SOLVER_H_

#include "common_config.h"
#include "fitting_solver.h"

COMMON_BEGIN_NAMESPACE

class _DLL_DECLARE_ GaussianBasisFittingSolver : FittingSolver {
public:
	GaussianBasisFittingSolver();
	~GaussianBasisFittingSolver();
	bool Solve(std::vector<Point>& points) override;
	const std::vector<std::tuple<double, double>>& GetLastSolution() const;

private:
	std::vector<std::tuple<double, double>> last_solution_;
};

COMMON_END_NAMESPACE

#endif // !GAUSSIAN_BASIS_FITTING_SOLVER_H_