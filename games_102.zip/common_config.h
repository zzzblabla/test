#ifndef COMMON_CONFIG_H_
#define COMMON_CONFIG_H_

#ifdef DLLEXPORT
#define _DLL_DECLARE_ __declspec(dllexport)
#else
#define _DLL_DECLARE_ __declspec(dllimport)
#endif // DLLEXPORT

#ifndef COMMON_BEGIN_NAMESPACE
#define COMMON_BEGIN_NAMESPACE namespace Games {
#endif

#ifndef COMMON_END_NAMESPACE
#define COMMON_END_NAMESPACE }
#endif

#endif // !COMMON_CONFIG_H_