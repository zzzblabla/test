#include "pch.h"
#include <algorithm>
#include <Eigen/Dense>
#include "point.h"
#include "polynomial_fitting_solver.h"

COMMON_BEGIN_NAMESPACE

PolynomialFittingSolver::PolynomialFittingSolver() :
	degree_(1) {
}

PolynomialFittingSolver::~PolynomialFittingSolver() {
	
}

void PolynomialFittingSolver::SetSolveDegree(unsigned int degree) {
	degree_ = degree;
}

bool PolynomialFittingSolver::Solve(std::vector<Point>& points) {
	std::sort(points.begin(), points.end(), [](const Point& x, const Point& y)
		{
			return x.GetX() < y.GetX() || (x.GetX() == y.GetX() && x.GetY() < y.GetY());
		});
	size_t point_size = points.size();
	if (point_size != degree_ + 1) {
		return false;
	}
	std::vector<double> vCoefficients(degree_ + 1, 0);
	Eigen::MatrixXd coefficients(degree_ + 1, degree_ + 1);
	Eigen::MatrixXd value(degree_ + 1, 1);
	for (size_t index = 0; index < point_size; index++) {
		double dX = points[index].GetX();
		double dSum = 0;
		double dCurrent = 1;
		for (unsigned int uiDegree = 0; uiDegree <= degree_; uiDegree++) {
			coefficients(index, uiDegree) = dCurrent;
			dCurrent *= dX;
		}
		value(index, 0) = points[index].GetY();
	}
	auto solution = coefficients.inverse() * value;
	last_solution_.clear();
	for (unsigned int index = 0; index <= degree_; index++) {
		last_solution_.push_back(solution(index, 0));
	}
	return true;
}

const std::vector<double>& PolynomialFittingSolver::GetLastSolution() const {
	return this->last_solution_;
}

COMMON_END_NAMESPACE