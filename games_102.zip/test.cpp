#include "pch.h"
#include <random>
#include "point.h"
#include "polynomial_fitting_solver.h"
#include "gaussian_basis_fitting_solver.h"

COMMON_BEGIN_NAMESPACE

TEST(TestCaseName, TestName) {
  EXPECT_EQ(1, 1);
  EXPECT_TRUE(true);
}

TEST(PolynomialFittingSolver, Degree2N1) {
	Games::PolynomialFittingSolver solver;
	solver.SetSolveDegree(2);
	//x^2+2x+1;
	std::vector<Games::Point> points;
	points.emplace_back(-2, 1);
	points.emplace_back(-1, 0);
	points.emplace_back(0, 1);
	bool solved = solver.Solve(points);
	EXPECT_TRUE(solved);
	auto& solution = solver.GetLastSolution();
	EXPECT_EQ(solution[0], 1);
	EXPECT_EQ(solution[1], 2);
	EXPECT_EQ(solution[2], 1);
	EXPECT_TRUE(true);
}

TEST(PolynomialFittingSolver, Degree2N2) {
	Games::PolynomialFittingSolver solver;
	solver.SetSolveDegree(2);
	//x^2-2x+1;
	std::vector<Games::Point> points;
	points.emplace_back(-2, 9);
	points.emplace_back(-1, 4);
	points.emplace_back(0, 1);
	bool solved = solver.Solve(points);
	EXPECT_TRUE(solved);
	auto& solution = solver.GetLastSolution();
	EXPECT_EQ(solution[0], 1);
	EXPECT_EQ(solution[1], -2);
	EXPECT_EQ(solution[2], 1);
	EXPECT_TRUE(true);
}

TEST(PolynomialFittingSolver, DegreeRandom) {
	Games::PolynomialFittingSolver solver;
	std::random_device random_device;
	std::mt19937 mt(random_device());
	std::uniform_real_distribution<double> dist(2.0, 8.0);
	int degree = static_cast<int>(dist(mt));
	
	std::vector<double> coefficients;
	for (int index = 0; index <= degree; index++) {
		coefficients.push_back(static_cast<int>(dist(mt)));
	}
	std::vector<Games::Point> points;
	for (int index = 0; index <= degree; index++) {
		double x = 1;
		double y = 0;
		for (int p = 0; p <= degree; p++) {
			y += x * coefficients[p];
			x *= index;
		}
		points.emplace_back(index, y);
	}
	solver.SetSolveDegree(degree);
	bool solved = solver.Solve(points);
	EXPECT_TRUE(solved);
	auto& solution = solver.GetLastSolution();
	for (int index = 0; index <= degree; index++) {
		EXPECT_LE(abs(coefficients[index] - solution[index]), 0.0001);
	}
	EXPECT_TRUE(true);
}

TEST(GaussianBasisFittingSolver, Gaussian1) {
	Games::GaussianBasisFittingSolver solver;
	//exp(-(x-1)^2/2)+exp(-(x-2)^2/2)+exp(-(x-3)^2/2);
	auto pExp = [](double x) {
		return exp(-(x - 1) * (x - 1) / 2.0) + exp(-(x - 2) * (x - 2) / 2.0) + exp(-(x - 3) * (x - 3) / 2.0);
	};
	std::vector<Games::Point> points;
	points.emplace_back(1, pExp(1));
	points.emplace_back(2, pExp(2));
	points.emplace_back(3, pExp(3));
	bool solved = solver.Solve(points);
	EXPECT_TRUE(solved);
	auto& solution = solver.GetLastSolution();
	auto pResult = [&solution](double x) {
		double dSum = 0;
		for (const auto& p : solution) {
			double dCenter = std::get<1>(p);
			dSum += std::get<0>(p) * exp(-(x - dCenter) * (x - dCenter) / 2.0);
		}
		return dSum;
	};
	EXPECT_LE(abs(std::get<0>(solution[0]) - 1), 0.00001);
	EXPECT_LE(abs(pExp(3.5) - pResult(3.5)), 0.001);
	EXPECT_TRUE(true);
}

COMMON_END_NAMESPACE