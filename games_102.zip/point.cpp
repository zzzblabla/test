#include "pch.h"
#include "point.h"

COMMON_BEGIN_NAMESPACE

Point::Point() :
	_dX(0), _dY(0) {
}

Point::Point(double dX, double dY) :
	_dX(dX), _dY(dY) {
}

Point::~Point() {

}

double Point::GetX() const {
	return _dX;
}

double Point::GetY() const {
	return _dY;
}

COMMON_END_NAMESPACE