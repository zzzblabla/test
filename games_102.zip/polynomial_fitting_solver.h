#pragma once
#ifndef POLYNOMIAL_FITTING_SOLVER_H_
#define POLYNOMIAL_FITTING_SOLVER_H_

#include "common_config.h"
#include "fitting_solver.h"

COMMON_BEGIN_NAMESPACE

class _DLL_DECLARE_ PolynomialFittingSolver : FittingSolver {
public:
	PolynomialFittingSolver();
	~PolynomialFittingSolver();
	void SetSolveDegree(unsigned int degree);
	bool Solve(std::vector<Point>& points) override;
	const std::vector<double>& GetLastSolution() const;

private:
	unsigned int degree_;
	std::vector<double> last_solution_;
};

COMMON_END_NAMESPACE

#endif // ! POLYNOMIAL_FITTING_SOLVER_H_